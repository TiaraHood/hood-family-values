# Hood Family Values — Quick Publishing Guide

## GitHub Pages

1. Sign in at https://github.com/
2. Create a **Public** repository named `hood-family-values`.
3. Upload all files and folders from this package so `index.html` is at the repository root.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select **main** and **/(root)**, then click **Save**.
7. Wait for GitHub to publish the site, then open the URL GitHub displays.

## Do not upload
Do not add any Supabase secret/service-role key. The included `config.js` is intended for browser use and contains only the publishable key.

## Test accounts
Use two separate test email addresses before inviting the whole family. Confirm that Account A can create a profile and connect to Account B, and that both can access the shared family content according to the configured policies.

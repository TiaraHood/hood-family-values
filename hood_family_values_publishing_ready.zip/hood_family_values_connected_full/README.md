# Hood Family Values — Publishing Package

This package is configured for the Hood Family Values Supabase project and is ready to publish as a static website.

## Supabase setup
The website uses these Supabase resources:
- `profiles`
- `family_relationships`
- `family_photos`
- `announcements`
- `reunion_info`
- Row Level Security on the application tables
- `family-photos` private Storage bucket
- Storage policies for authenticated family members

The package contains `config.js` with the browser-safe Supabase URL and publishable key. Never add a Supabase `sb_secret_*` or `service_role` key to this website.

## Publish on GitHub Pages
1. Create a GitHub repository named `hood-family-values`.
2. Upload the contents of this folder (not the ZIP file itself).
3. In GitHub, open **Settings → Pages**.
4. Choose **Deploy from a branch**, select the `main` branch and `/ (root)`, then save.
5. Open the GitHub Pages URL shown by GitHub.

## First test after publishing
Create two test accounts and verify:
1. Sign up / login
2. Profile creation and editing
3. Profile photo upload
4. Family connection creation
5. Family directory
6. Family photo upload
7. Reunion information
8. Announcements

## Important
The site uses a private Supabase Storage bucket and signed URLs for images. The browser key in `config.js` is a publishable client key; it is not a database password.
